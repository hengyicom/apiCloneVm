package com.vmware.vim25;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="ActionParameter")
@XmlEnum
public enum ActionParameter
{
  TARGET_NAME, ALARM_NAME, OLD_STATUS, NEW_STATUS, TRIGGERING_SUMMARY, DECLARING_SUMMARY, EVENT_DESCRIPTION, TARGET, ALARM;

  private final String value;

  public String value()
  {
    return this.value;
  }

  public static ActionParameter fromValue(String paramString) {
    ActionParameter[] arrayOfActionParameter = values(); int i = arrayOfActionParameter.length; for (int j = 0; j < i; ++j) { ActionParameter localActionParameter = arrayOfActionParameter[j];
      if (localActionParameter.value.equals(paramString))
        return localActionParameter;
    }

    throw new IllegalArgumentException(paramString);
  }
}