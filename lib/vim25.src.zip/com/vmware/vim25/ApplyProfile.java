package com.vmware.vim25;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="ApplyProfile", propOrder={"enabled", "policy", "profileTypeName", "profileVersion", "property"})
@XmlSeeAlso({DvsProfile.class, FirewallProfile.class, NasStorageProfile.class, NetworkProfile.class, StorageProfile.class, PnicUplinkProfile.class, AuthenticationProfile.class, DateTimeProfile.class, PermissionProfile.class, IpAddressProfile.class, ActiveDirectoryProfile.class, NumPortsProfile.class, LinkProfile.class, NetworkPolicyProfile.class, VirtualSwitchProfile.class, OptionProfile.class, StaticRouteProfile.class, HostMemoryProfile.class, NetStackInstanceProfile.class, ServiceProfile.class, ProfileApplyProfileElement.class, VirtualSwitchSelectionProfile.class, UserProfile.class, VlanProfile.class, PhysicalNicProfile.class, FirewallProfileRulesetProfile.class, SecurityProfile.class, UserGroupProfile.class, PortGroupProfile.class, HostApplyProfile.class, DvsVNicProfile.class, IpRouteProfile.class, NetworkProfileDnsConfigProfile.class})
public class ApplyProfile extends DynamicData
{
  protected boolean enabled;
  protected List<ProfilePolicy> policy;
  protected String profileTypeName;
  protected String profileVersion;
  protected List<ProfileApplyProfileProperty> property;

  public boolean isEnabled()
  {
    return this.enabled;
  }

  public void setEnabled(boolean paramBoolean)
  {
    this.enabled = paramBoolean;
  }

  public List<ProfilePolicy> getPolicy()
  {
    if (this.policy == null)
      this.policy = new ArrayList();

    return this.policy;
  }

  public String getProfileTypeName()
  {
    return this.profileTypeName;
  }

  public void setProfileTypeName(String paramString)
  {
    this.profileTypeName = paramString;
  }

  public String getProfileVersion()
  {
    return this.profileVersion;
  }

  public void setProfileVersion(String paramString)
  {
    this.profileVersion = paramString;
  }

  public List<ProfileApplyProfileProperty> getProperty()
  {
    if (this.property == null)
      this.property = new ArrayList();

    return this.property;
  }
}