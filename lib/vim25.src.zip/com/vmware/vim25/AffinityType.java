package com.vmware.vim25;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="AffinityType")
@XmlEnum
public enum AffinityType
{
  MEMORY, CPU;

  private final String value;

  public String value()
  {
    return this.value;
  }

  public static AffinityType fromValue(String paramString) {
    AffinityType[] arrayOfAffinityType = values(); int i = arrayOfAffinityType.length; for (int j = 0; j < i; ++j) { AffinityType localAffinityType = arrayOfAffinityType[j];
      if (localAffinityType.value.equals(paramString))
        return localAffinityType;
    }

    throw new IllegalArgumentException(paramString);
  }
}