package com.vmware.vim25;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="ActionType")
@XmlEnum
public enum ActionType
{
  MIGRATION_V_1, VM_POWER_V_1, HOST_POWER_V_1, HOST_MAINTENANCE_V_1, STORAGE_MIGRATION_V_1, STORAGE_PLACEMENT_V_1;

  private final String value;

  public String value()
  {
    return this.value;
  }

  public static ActionType fromValue(String paramString) {
    ActionType[] arrayOfActionType = values(); int i = arrayOfActionType.length; for (int j = 0; j < i; ++j) { ActionType localActionType = arrayOfActionType[j];
      if (localActionType.value.equals(paramString))
        return localActionType;
    }

    throw new IllegalArgumentException(paramString);
  }
}