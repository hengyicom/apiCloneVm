package com.vmware.vim25;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="AgentInstallFailedReason")
@XmlEnum
public enum AgentInstallFailedReason
{
  NOT_ENOUGH_SPACE_ON_DEVICE, PREPARE_TO_UPGRADE_FAILED, AGENT_NOT_RUNNING, AGENT_NOT_REACHABLE, INSTALL_TIMEDOUT, SIGNATURE_VERIFICATION_FAILED, AGENT_UPLOAD_FAILED, AGENT_UPLOAD_TIMEDOUT, UNKNOWN_INSTALLER_ERROR;

  private final String value;

  public String value()
  {
    return this.value;
  }

  public static AgentInstallFailedReason fromValue(String paramString) {
    AgentInstallFailedReason[] arrayOfAgentInstallFailedReason = values(); int i = arrayOfAgentInstallFailedReason.length; for (int j = 0; j < i; ++j) { AgentInstallFailedReason localAgentInstallFailedReason = arrayOfAgentInstallFailedReason[j];
      if (localAgentInstallFailedReason.value.equals(paramString))
        return localAgentInstallFailedReason;
    }

    throw new IllegalArgumentException(paramString);
  }
}