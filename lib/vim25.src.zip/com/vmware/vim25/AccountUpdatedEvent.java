package com.vmware.vim25;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="AccountUpdatedEvent", propOrder={"spec", "group"})
public class AccountUpdatedEvent extends HostEvent
{

  @XmlElement(required=true)
  protected HostAccountSpec spec;
  protected boolean group;

  public HostAccountSpec getSpec()
  {
    return this.spec;
  }

  public void setSpec(HostAccountSpec paramHostAccountSpec)
  {
    this.spec = paramHostAccountSpec;
  }

  public boolean isGroup()
  {
    return this.group;
  }

  public void setGroup(boolean paramBoolean)
  {
    this.group = paramBoolean;
  }
}